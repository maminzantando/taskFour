<!DOCTYPE html>
<html lang="en">
<head>
<title>Personal blog post</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>

body {
  font-family: Cursive;
  margin: 0;
}

.header {
  padding: 5px;
  text-align: center;
  color: black;
  font-size: 30px;
}

.column {
  float: left;
  width: 25%;
  padding: 15px;
}

.text{
   width:100%;
   height:5vh;
   text-align:center;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}
.fa {
  padding: 11px;
  font-size: 11px;
  width: 11px;
  text-align: center;
  text-decoration: none;
  margin: 6px 10px;
  border-radius: 50%;
}

.fa:hover {
    opacity: 0.8;
}

.fa-facebook {
  background: #1877f2;
  color: white;
}

.fa-instagram {
  background: #c32aa3;
  color: white;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
}

.navbar {
  width: 100%;
  background-color: #554f4f;
  overflow: auto;
}

.navbar a {
  float: left;
  padding: 14px;
  color: white;
  text-decoration: none;
  font-size: 18px;
  width: 31%; 
  text-align: center;
}

.navbar a:hover {
  background-color: gray;
}

/* For mobile phones: */
[class*="col-"] {
  width: 100%;
}

@media only screen and (min-width: 600px) {
  /* For tablets: */
  .col-s-1 {width: 8.33%;}
  .col-s-2 {width: 16.66%;}
  .col-s-3 {width: 25%;}
  .col-s-4 {width: 33.33%;}
  .col-s-5 {width: 41.66%;}
  .col-s-6 {width: 50%;}
  .col-s-7 {width: 58.33%;}
  .col-s-8 {width: 66.66%;}
  .col-s-9 {width: 75%;}
  .col-s-10 {width: 83.33%;}
  .col-s-11 {width: 91.66%;}
  .col-s-12 {width: 100%;}
}
@media only screen and (min-width: 768px) {
  /* For desktop: */
  .col-1 {width: 8.33%;}
  .col-2 {width: 16.66%;}
  .col-3 {width: 25%;}
  .col-4 {width: 33.33%;}
  .col-5 {width: 41.66%;}
  .col-6 {width: 50%;}
  .col-7 {width: 58.33%;}
  .col-8 {width: 66.66%;}
  .col-9 {width: 75%;}
  .col-10 {width: 83.33%;}
  .col-11 {width: 91.66%;}
  .col-12 {width: 100%;}
}
</style>
</head>
<body style="background-color:#d8cfcf">

<div class="header">
  <h2><em>Ntando Maminza personal blog</em></h2>
  <p>Find out about my thoughts, experiences, interests, and hobbies.</p>
</div>
<div class="navbar" >
  <a href="taskFour"><i class="fa fa-fw fa-home"></i> Home</a> 
  <a href="About.php"><i class="fa fa-fw fa-search"></i> About</a> 
  <a href="contact.php"><i class="fa fa-fw fa-envelope"></i> Contact</a> 
  
</div>
<br>

<div class="row">

  <div class="column">    
  <img src="IMG-20210904-WA0012.jpg" style="width:300px">
  
  <!-- Add font awesome icons -->
<a href="https://www.facebook.com/ntando.wehkhathaza?mibextid=LQQJ4d" class="fa fa-facebook"></a>
<a href="https://ig.me/1MbmEH4W4YMCq7e" class="fa fa-instagram"></a>
<a href="https://www.linkedin.com/feed/?trk=guest_homepage-basic_google-one-tap-submit" class="fa fa-linkedin"></a>
  </div>
  
  <div class="column">
  <h2>My Thoughts</h2>
  <p>We living in a world now where most things happens through technology. I believe that
    software development is changing lives, mine and yours because it is all about solving a problem
  </p>
  <br>

  <h2>Experiences</h2>
  <p>I am a third year at rosebank college in braamfontein. Through out my last two years doing software 
    development i have learnt a lot, mainly Java, C#, HTML, CSS and Javascript.</p>
  <br>
    </div>

    <div class="column">    
    <h2>Interests</h2>
  <p>I have interest in learning more to advance my programming skills. Virtual Vigilantes have also 
    helped in achieving that.
  </p>
  <br>

  <h2>Hobbies</h2>
  <p>Programming is definitely one of my favourite hobby. Any business idea that comes to my mind 
    gives me something to code and create.
  </p>
  </div>
  
</div>

</div>

</body>
</html>
