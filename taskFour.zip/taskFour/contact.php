<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>

* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 10px;
  border: 2px solid whitesmoke;
  border-radius: 6px;
  box-sizing: border-box;
  margin-top: 8px;
  margin-bottom: 15px;
  resize: vertical;
}

input[type=submit] {
  background-color: #a04d4d;
  color: white;
  padding: 14px 22px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #f87f7f;
}

.container {
  border-radius: 6px;
  background-color: #bbadad;
  padding: 18px;
}

.navbar {
  width: 100%;
  background-color: #554f4f;
  overflow: auto;
}

.navbar a {
  float: left;
  padding: 14px;
  color: white;
  text-decoration: none;
  font-size: 18px;
  width: 33%; 
  text-align: center;
}

.navbar a:hover {
  background-color: gray;
}
</style>
</head>
<body style=background-color:#d8cfcf>

<div class="navbar">
  <a href="taskFour"><i class="fa fa-fw fa-home"></i> Home</a> 
  <a href="About.php"><i class="fa fa-fw fa-search"></i> About</a> 
  <a href="contact.php"><i class="fa fa-fw fa-envelope"></i> Contact</a> 
  
</div>

<h3 style="padding: 2px 550px">Contact Form</h3>
<p style="padding: 2px 500px">Hello! Feel free to reach out to me by filling out this form that you see below.</p>
<br>
<div class="container">
  <form action="/action_page.php">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="email">Email</label>
    <input type="text" id="email" name="email" placeholder="Your email..">
</input>

    <label for="message">Message</label>
    <textarea id="message" name="message" placeholder="Write something.." style="height:80px"></textarea>

    <input type="submit" value="Submit">
  </form>
</div>

</body>
</html>
