<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 50%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.about-section {
  padding: 45px;
  text-align: center;
  background-color: #bbadad;
  color: white;
}

.container {
  padding: 0 15px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.navbar {
  width: 100%;
  background-color: #554f4f;
  overflow: auto;
}

.navbar a {
  float: left;
  padding: 14px;
  color: white;
  text-decoration: none;
  font-size: 18px;
  width: 33%; 
  text-align: center;
}

.navbar a:hover {
  background-color: gray;
}

.wrapper {
  height: 270px;
  width: 270px;
  border-radius: 50%;
  overflow: hidden;
  border: 6px solid #fff;
  float: center;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>
<body style=background-color:#d8cfcf>

<div class="navbar">
  <a href="taskFour.php"><i class="fa fa-fw fa-home"></i> Home</a> 
  <a href="About.php"><i class="fa fa-fw fa-search"></i> About</a> 
  <a href="contact.php"><i class="fa fa-fw fa-envelope"></i> Contact</a> 
  
</div>

<div class="about-section">
  <h1>About Me</h1>
  <p>In this page you will find or know me better as I get into my personal.</p>
</div>

<h2 style="text-align:center">Get to know me</h2>

<div class="row">
  <div class="column">
    
      
      <div class="container">
        
        <br><p>Welcome! With clarity , compassion, and integrity guiding each interaction, 
            let me be not an individual but a purveyor of positivity and purpose.<br><br>

My value proposition is simple: do good and foster positive change. I am an advocate for clear communication 
and being unbridledly yourself. </br> I stand not as the hero of my own story, but humbly in service to humanity. 
These are not about who I am and their effect on people; they are things that I have done within my actions, 
tests of each word, each action.<br><br>

Thank you for visiting, and may your journey be filled with light, love, and boundless compassion.</p>
        
      </div>
    
  </div>

  
  <div class="column">
    
  <div class="wrapper">
    <img src="IMG-about.jpg" alt="Nature" style="width:100%">
   
  </div>
      
  </div>
</div>

</body>
</html>
